const x = document.getElementById("s");
const day = document.getElementById("d");
const night = document.getElementById("n");


function nightTime() {
  x.src = "moon.png";
document.body.style.background="black"
}

function dayTime() {
  x.src = "sun.png";
  document.body.style.background = "black"
}

